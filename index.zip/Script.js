function toggleTaxInput() {
    const taxOption = document.getElementById('tax-option').value;
    const taxRateContainer = document.getElementById('tax-rate-container');
    taxRateContainer.style.display = taxOption === 'with-tax' ? 'block' : 'none';
}

const ctx = document.getElementById('dividendChart').getContext('2d');
let chart;

function calculateDividend() {
    const investmentAmount = parseFloat(document.getElementById('investment-amount').value);
    const annualYield = parseFloat(document.getElementById('annual-yield').value) / 100;
    const dividendFrequency = document.getElementById('dividend-frequency').value;
    const taxOption = document.getElementById('tax-option').value;
    const taxRate = parseFloat(document.getElementById('tax-rate').value) / 100 || 0;

    if (isNaN(investmentAmount) || investmentAmount <= 0 || isNaN(annualYield) || annualYield < 0) {
        alert("Please enter valid inputs.");
        return;
    }

    let annualIncome = investmentAmount * annualYield;
    if (taxOption === 'with-tax') {
        annualIncome -= annualIncome * taxRate;
    }

    let periods = 1;
    switch (dividendFrequency) {
        case 'quarterly': periods = 4; break;
        case 'monthly': periods = 12; break;
    }

    const dividendPerPeriod = annualIncome / periods;
    const dividendYield = annualYield * 100;

    document.getElementById('annual-income').innerText = `₹${annualIncome.toFixed(2)}`;
    document.getElementById('dividend-per-period').innerText = `₹${dividendPerPeriod.toFixed(2)}`;
    document.getElementById('dividend-yield').innerText = `${dividendYield.toFixed(2)}%`;

    const labels = Array.from({ length: periods }, (_, i) => `Period ${i + 1}`);
    const data = Array.from({ length: periods }, () => dividendPerPeriod);

    if (chart) {
        chart.destroy();
    }

    chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Dividend Per Period',
                data: data,
                backgroundColor: '#007bff',
                borderColor: '#007bff',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Dividend (₹)'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Periods'
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
}